<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;

class AdminController extends Controller
{
    public function setUser(Request $req)
    {
        if ($req) {
            $user = new User;
            $user->email = $req->email;
            $user->password = $req->password;
            $user->save();

            $response = [
                'user_id' => $user->id,
                'message' => "Saved successfull"
            ];
            return response()->json($response);
            
        } else {
            return response()->json(['message' => "Saved not successfull",]);
            
        }
        
    }
}
